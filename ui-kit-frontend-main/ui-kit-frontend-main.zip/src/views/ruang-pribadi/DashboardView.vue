<template>
  <div class="flex items-center justify-center h-full">
    <div class="text-center">
      <h1 class="text-4xl font-bold text-primary-700 mb-4">
        Selamat Datang
      </h1>
      <p class="text-lg text-gray-600">
        di Sistem Logbook DWS - BSSN
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
// Simple dashboard - just welcome message
</script>