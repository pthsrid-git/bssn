<template>
  <div class="flex flex-row flex-wrap items-center justify-center gap-2">
    <BreadcrumbDefault />
  </div>
</template>

<script setup lang="ts">
import BreadcrumbDefault from '@/components/breadcrumb/BreadcrumbDefault.vue'
</script>
