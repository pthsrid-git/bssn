<template>
  <div class="flex flex-row flex-wrap items-center justify-center gap-2">
    <LinkDefault>Link Default</LinkDefault>
  </div>
</template>

<script setup lang="ts">
import LinkDefault from '@/components/link/LinkDefault.vue'
</script>
