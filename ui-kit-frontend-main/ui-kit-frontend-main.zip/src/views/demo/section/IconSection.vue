<template>
  <div class="font-bold text-center">icon: fas</div>
  <div class="grid grid-cols-1 gap-4 mb-8 text-sm text-primary-500 md:grid-cols-3 xl:grid-cols-5">
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'angle-down']" class="w-6 h-6" />
      angle-down
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'angle-left']" class="w-6 h-6" />
      angle-left
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'angle-right']" class="w-6 h-6" />
      angle-right
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'angle-up']" class="w-6 h-6" />
      angle-up
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'arrow-down']" class="w-6 h-6" />
      arrow-down
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'arrow-left']" class="w-6 h-6" />
      arrow-left
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'arrow-right']" class="w-6 h-6" />
      arrow-right
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'arrow-up']" class="w-6 h-6" />
      arrow-up
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'circle']" class="w-6 h-6" />
      circle
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'minus']" class="w-6 h-6" />
      minus
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'plus']" class="w-6 h-6" />
      plus
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fas', 'xmark']" class="w-6 h-6" />
      xmark
    </div>
  </div>
  <div class="font-bold text-center">icon: fad</div>
  <div class="grid grid-cols-1 gap-4 mb-4 text-sm text-primary-500 md:grid-cols-3 xl:grid-cols-5">
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'alarm-clock']" class="w-6 h-6" />
      alarm-clock
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'arrows-to-circle']" class="w-6 h-6" />
      arrows-to-circle
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'bell']" class="w-6 h-6" />
      bell
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'brain-circuit']" class="w-6 h-6" />
      brain-circuit
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'book']" class="w-6 h-6" />
      book
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'books']" class="w-6 h-6" />
      books
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'book-user']" class="w-6 h-6" />
      book-user
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'box-archive']" class="w-6 h-6" />
      box-archive
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'building']" class="w-6 h-6" />
      building
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'building-shield']" class="w-6 h-6" />
      building-shield
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'bullseye']" class="w-6 h-6" />
      bullseye
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'calendar-days']" class="w-6 h-6" />
      calendar-days
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'chart-column']" class="w-6 h-6" />
      chart-column
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'circle-check']" class="w-6 h-6" />
      circle-check
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'circle-dot']" class="w-6 h-6" />
      circle-dot
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'circle-exclamation']" class="w-6 h-6" />
      circle-exclamation
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'circle-info']" class="w-6 h-6" />
      circle-info
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'circle-o']" class="w-6 h-6" />
      circle-o
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'circle-plus']" class="w-6 h-6" />
      circle-plus
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'circle-xmark']" class="w-6 h-6" />
      circle-xmark
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'clipboard-list-check']" class="w-6 h-6" />
      clipboard-list-check
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'clipboard-user']" class="w-6 h-6" />
      clipboard-user
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'clock']" class="w-6 h-6" />
      clock
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'comments']" class="w-6 h-6" />
      comments
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'cube']" class="w-6 h-6" />
      cube
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'diagram-subtask']" class="w-6 h-6" />
      diagram-subtask
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'download']" class="w-6 h-6" />
      download
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'envelopes-bulk']" class="w-6 h-6" />
      envelopes-bulk
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'eye']" class="w-6 h-6" />
      eye
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'file']" class="w-6 h-6" />
      file
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'file-certificate']" class="w-6 h-6" />
      file-certificate
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'file-check']" class="w-6 h-6" />
      file-check
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'file-lines']" class="w-6 h-6" />
      file-lines
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'file-pen']" class="w-6 h-6" />
      file-pen
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'file-plus']" class="w-6 h-6" />
      file-plus
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'file-shield']" class="w-6 h-6" />
      file-shield
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'file-zipper']" class="w-6 h-6" />
      file-zipper
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'floppy-disk']" class="w-6 h-6" />
      floppy-disk
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'folder']" class="w-6 h-6" />
      folder
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'folder-bookmark']" class="w-6 h-6" />
      folder-bookmark
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'globe']" class="w-6 h-6" />
      globe
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'globe-pointer']" class="w-6 h-6" />
      globe-pointer
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'head-side-brain']" class="w-6 h-6" />
      head-side-brain
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'history']" class="w-6 h-6" />
      history
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'hourglass-start']" class="w-6 h-6" />
      hourglass-start
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'house']" class="w-6 h-6" />
      house
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'house-medical-flag']" class="w-6 h-6" />
      house-medical-flag
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'inbox']" class="w-6 h-6" />
      inbox
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'inbox-in']" class="w-6 h-6" />
      inbox-in
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'inbox-out']" class="w-6 h-6" />
      inbox-out
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'landmark']" class="w-6 h-6" />
      landmark
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'laptop-mobile']" class="w-6 h-6" />
      laptop-mobile
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'location-dot']" class="w-6 h-6" />
      location-dot
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'lock-keyhole']" class="w-6 h-6" />
      lock-keyhole
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'magnifying-glass']" class="w-6 h-6" />
      magnifying-glass
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'megaphone']" class="w-6 h-6" />
      megaphone
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'memo-circle-info']" class="w-6 h-6" />
      memo-circle-info
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'memo-pad']" class="w-6 h-6" />
      memo-pad
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'messages']" class="w-6 h-6" />
      messages
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'microchip']" class="w-6 h-6" />
      microchip
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'mobile']" class="w-6 h-6" />
      mobile
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'money-bills']" class="w-6 h-6" />
      money-bills
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'money-from-bracket']" class="w-6 h-6" />
      money-from-bracket
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'newspaper']" class="w-6 h-6" />
      newspaper
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'paper-plane-top']" class="w-6 h-6" />
      paper-plane-top
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'pencil-line']" class="w-6 h-6" />
      pencil-line
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'pen-to-square']" class="w-6 h-6" />
      pen-to-square
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'people-group']" class="w-6 h-6" />
      people-group
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'poll-people']" class="w-6 h-6" />
      poll-people
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'receipt']" class="w-6 h-6" />
      receipt
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'rectangle-barcode']" class="w-6 h-6" />
      rectangle-barcode
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'scale-balanced']" class="w-6 h-6" />
      scale-balanced
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'shapes']" class="w-6 h-6" />
      shapes
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'share-nodes']" class="w-6 h-6" />
      share-nodes
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'shield-check']" class="w-6 h-6" />
      shield-check
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'shield-halved']" class="w-6 h-6" />
      shield-halved
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'shield-user']" class="w-6 h-6" />
      shield-user
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'square-poll-vertical']" class="w-6 h-6" />
      square-poll-vertical
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'thumbs-up']" class="w-6 h-6" />
      thumbs-up
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'times-circle']" class="w-6 h-6" />
      times-circle
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'traffic-cone']" class="w-6 h-6" />
      traffic-cone
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'trash-can']" class="w-6 h-6" />
      trash-can
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'triangle-exclamation']" class="w-6 h-6" />
      triangle-exclamation
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'user']" class="w-6 h-6" />
      user
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'user-crown']" class="w-6 h-6" />
      user-crown
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'user-police-tie']" class="w-6 h-6" />
      user-police-tie
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'user-tie-hair']" class="w-6 h-6" />
      user-tie-hair
    </div>
    <div class="flex flex-col items-center gap-2 text-center">
      <font-awesome-icon :icon="['fad', 'whistle']" class="w-6 h-6" />
      whistle
    </div>
  </div>
  <div class="flex flex-row flex-wrap items-center justify-center gap-8">
    <IconLoading />
    <IconMenu />
  </div>
</template>

<script setup lang="ts">
import IconLoading from '@/components/icon/IconLoading.vue'
import IconMenu from '@/components/icon/IconMenu.vue'
</script>
