<template>
  <div class="flex flex-row items-center gap-4">
    <img src="@/assets/images/logo-bssn-light.png" class="w-48" />
  </div>
</template>
