<template>
  <div :class="computedClasses">
    {{ value > 99 ? '99+' : value }}
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

import type { BadgeVariant } from '@/models'

const props = defineProps({
  value: {
    type: Number,
    default: 0
  },
  variant: {
    type: String as () => BadgeVariant,
    default: 'default'
  },
  customClass: {
    type: String,
    default: ''
  }
})

const baseClasses =
  'font-semibold text-[10px] rounded-full px-1.5 w-5 h-5 flex items-center justify-center '

const variantClasses: Record<typeof props.variant, string> = {
  default: 'bg-neutral-500 text-gray-900',
  primary: 'bg-primary-500 text-white',
  info: 'bg-info-500 text-white',
  warning: 'bg-warning-500 text-gray-900',
  success: 'bg-success-500 text-white',
  danger: 'bg-danger-500 text-white'
}

const computedClasses = computed(() =>
  [baseClasses, variantClasses[props.variant], props.customClass].join(' ')
)
</script>
