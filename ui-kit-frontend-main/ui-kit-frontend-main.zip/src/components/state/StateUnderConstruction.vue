<template>
  <div class="flex flex-col items-center justify-center w-full h-full gap-2 p-8">
    <font-awesome-icon :icon="['fad', 'traffic-cone']" class="w-8 h-8 text-warning-500" />
    <p class="text-sm text-center">Sedang dalam proses pengembangan.</p>
  </div>
</template>
