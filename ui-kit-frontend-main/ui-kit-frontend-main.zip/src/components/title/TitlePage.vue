<template>
  <h1 class="p-1 text-base font-semibold uppercase"><slot></slot></h1>
</template>
