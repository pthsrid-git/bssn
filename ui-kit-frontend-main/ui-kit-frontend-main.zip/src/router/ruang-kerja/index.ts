import { logbookKatimRoute } from './logbook-katim'
import { logbookAtasanRoute } from './logbook-atasan'

export const ruangKerjaRoutes = [logbookKatimRoute, logbookAtasanRoute]
