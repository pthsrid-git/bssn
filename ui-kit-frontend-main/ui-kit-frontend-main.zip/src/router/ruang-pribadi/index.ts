import { dashboardRoute } from './dashboard'
import { logbookRoute } from './logbook'

export const ruangPribadiRoutes = [dashboardRoute, logbookRoute]
