import CodeView from '@/views/demo/CodeView.vue'

export const codeRoute = {
  path: 'code',
  name: 'main.code',
  component: CodeView
}
